package fr.insalyon.tc.framework; 

public interface Animal {
    public String scream();
}
