import fr.insalyon.tc.framework.Animal; 

public class Bee implements Animal {
    public String scream() {
	return "buzz";
    }
}
