package fr.insalyon.tc.framework; 

public interface Animal {
    public abstract String scream();
}
