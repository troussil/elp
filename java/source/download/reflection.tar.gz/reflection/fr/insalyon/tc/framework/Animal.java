package fr.insalyon.tc.framework; 

public abstract class Animal {
    public abstract String scream();
}
