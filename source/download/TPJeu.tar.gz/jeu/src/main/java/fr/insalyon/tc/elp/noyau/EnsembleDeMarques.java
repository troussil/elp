package fr.insalyon.tc.elp.noyau; 

import java.util.Map; 
import java.util.HashMap; 

/**
 * Classe modélisant un ensemble de marques, 
 * c'est-à-dire une configuration de marques sur la grille. 
 */
public class EnsembleDeMarques {

    /** tableau associant marque et position */
    private Map<Position, Marque> mesMarques 
	= new HashMap<Position, Marque>();

    /** couleur du joueur gagnant (null si la partie est en cours ou 
     * si elle termine a egalite) */
    private Couleur couleurGagnante = null; 

    //-------------------- services ---------------------------

    /**
     * Methode indiquant si la partie est terminee:
     * - un joueur a aligne 3 marques ou 
     * - plus aucune position n'est à marquer
     * @return vrai si la partie est terminee, faux sinon
     */
    public boolean estTermine() {
	if (couleurGagnante == null) 
	    return ( mesMarques.size() == 9 );
	else 
	    return true; 
    }

    /**
     * Methode qui ajoute une marque donnee a une position donnee
     * @param uneMarque marque a ajouter 
     * @param unePosition position de la marque a ajouter
     */
    public void ajouterMarque(Marque uneMarque, Position unePosition) {
	mesMarques.put(unePosition, uneMarque);
 
	if (verifierTousLesAlignements(unePosition, uneMarque)) {
	    if (uneMarque.aMemeCouleur(Couleur.noir()))
		couleurGagnante = Couleur.noir(); 
	    else 
		couleurGagnante = Couleur.blanc(); 
	}  
    }

    /**
     * Methode qui retourne la marque se trouvant a la position donnee
     * @param unePosition toute position 
     * @return la marque a la position donnee, null si aucune marque 
     * ne s'y trouve. 
     */
    public Marque obtenirMarque(Position unePosition) {
	return mesMarques.get(unePosition); 
    }

    /**
     * Methode qui retourne la couleur gagnante
     * @return couleur gagnante, null si la partie est en cours ou 
     * termine nulle
     */
    public Couleur obtenirGagnant() {
	return couleurGagnante; 
    }

    //-------------------- operations internes ---------------------------

    /**
     * Methode qui verifie qu'un alignement donne de 3 positions porte une
     * meme marque donnee.
     * @param unAlignement tableau de 3 positions
     * @param uneMarque une marque
     * @return 'true' si les 3 positions sont marquee par 'uneMarque', 'false' sinon
     */
    private boolean verifierUnAlignement(Position[] unAlignement, Marque uneMarque) {
	if (unAlignement == null) 
	    return false; 
	else {
	    boolean aGagne = true; 
	    for (Position p: unAlignement)
		aGagne = aGagne && uneMarque.aMemeCouleur(mesMarques.get(p));
	    return aGagne; 
	}
	    
    } 

    /**
     * Methode qui verifie que tous les alignements concernant une position donnee
     * porte une meme marque donnee. 
     * @param unePosition position evaluee
     * @param uneMarque n'importe quelle marque
     * @return 'true' si les 3 positions sont marquee par 'uneMarque', 'false' sinon
     */
    private boolean verifierTousLesAlignements(Position unePosition, Marque uneMarque) {
	return verifierUnAlignement(unePosition.ligne(), uneMarque)
	    || verifierUnAlignement(unePosition.colonne(), uneMarque) 
	    || verifierUnAlignement(unePosition.diag1(), uneMarque) 
	    || verifierUnAlignement(unePosition.diag2(), uneMarque); 
    } 

}
