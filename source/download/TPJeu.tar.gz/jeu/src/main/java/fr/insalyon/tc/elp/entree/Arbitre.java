package fr.insalyon.tc.elp.entree; 

/**
 * Classe modelisant un arbitre synchronisant les actions
 * des 2 joueurs
 */
public class Arbitre {

    /**
     * Methode avec laquelle un joueur laisse la main, 
     * son thread reveille celui du joueur adverse, 
     * puis se met en attente. 
     */
    public synchronized void laisseLaMain() {
	try {

	    notify(); //reveille le joueur adverse
	    wait();   //attend que le joueur adverse joue

	} catch (InterruptedException e) {
	    System.err.println("ERR: interruption impromptue");
	}
    } 

    /**
     * Methode avec laquelle un joueur arrete de jouer, 
     * son thread reveille celui du joueur adverse
     */
    public synchronized void arrete() {
	notify(); //reveille le joueur adverse
    } 

}
