package fr.insalyon.tc.elp.entree; 

import fr.insalyon.tc.elp.noyau.Couleur; 
import fr.insalyon.tc.elp.noyau.Marque; 
import fr.insalyon.tc.elp.noyau.EnsembleDeMarques; 
import fr.insalyon.tc.elp.noyau.Position; 

/**
 * Classe modelisant un joueur
 */
public class Joueur implements Runnable {

    /** couleur du joueur */
    protected Couleur maCouleur;
    /** configuration des marques sur le damier */
    protected EnsembleDeMarques maConfiguration; 
    /** arbitre permettant de synchroniser les joueurs */
    protected Arbitre monArbitre; 
    /** lecteur capable de renvoyer le position
	que le joueur souhaite effectuer */
    protected LecteurPosition monLecteur;  

    /** 
     *  Constructeur
     * @param uneCouleur couleur du joueur
     * @param uneConfiguration configuration des marques
     * @param unArbitre arbitre
     * @param unLecteur lecteur
     */
    protected Joueur(Couleur uneCouleur, EnsembleDeMarques uneConfiguration, Arbitre unArbitre, LecteurPosition unLecteur) {
	maCouleur = uneCouleur; 
	maConfiguration = uneConfiguration;
	monArbitre = unArbitre; 
	monLecteur = unLecteur; 
    }

    /** 
     *  Constructeur d'un joueur blanc
     * @param uneConfiguration configuration des marques
     * @param unArbitre arbitre
     * @param unLecteur lecteur
     */
    public static Joueur joueurBlanc(EnsembleDeMarques uneConfiguration, Arbitre unArbitre, LecteurPosition unLecteur) {
	return new Joueur(Couleur.blanc(), uneConfiguration, unArbitre, unLecteur); 
    }

    /** 
     *  Constructeur d'un joueur noir
     * @param uneConfiguration configuration des marques
     * @param unArbitre arbitre
     * @param unLecteur lecteur
     */
    public static Joueur joueurNoir(EnsembleDeMarques uneConfiguration, Arbitre unArbitre, LecteurPosition unLecteur) {
	return new Joueur(Couleur.noir(), uneConfiguration, unArbitre, unLecteur); 
    }
    /**
     * Methode dans laquelle le joueur ajoute sa marque a une position donnee. 
     * Il laisse ensuite la main, pour laisser jouer l'adversaire. 
     */
    protected void jouer(Position unePosition) {
	maConfiguration.ajouterMarque(new Marque(maCouleur), unePosition); 
	monArbitre.laisseLaMain(); 
    }

    /**
     * Methode indiquant si un joueur a une couleur donnee
     * @param uneCouleur toute couleur
     * @return vrai si les couleurs sont identiques, faux sinon
     */
    public boolean aMemeCouleur(Couleur uneCouleur) {
	return (maCouleur.equals(uneCouleur)); 
    }

    /**
     * Representation textuelle du joueur
     * @return nom de la classe, suivi de la couleur du joueur
     */
    @Override
    public String toString() {
	return getClass().getName() + maCouleur; 
    }

    /**
     * Methode executee lors du demarrage du thread
     */
    @Override
    public void run() {
	
	//debut
	if (aMemeCouleur(Couleur.noir()))
	    monArbitre.laisseLaMain(); //attend le tour des blancs, qui commencent

	//cours du jeu
	while (!maConfiguration.estTermine()) {

	    System.out.print(toString() + " >> "); 

	    Position p = monLecteur.lire(); 
	    if (p != null) 
		jouer(p); 
	    else
		System.err.print("ERR: position illisible"); 

	    System.out.println(); 
	}

	//fin
	Couleur gagnant = maConfiguration.obtenirGagnant(); 
	System.out.print(toString() + " >> "); 
	if (gagnant == null) {
	    System.out.println(" :-| ");
	} else { 
	    if (aMemeCouleur(gagnant)) 
		System.out.println(" :-) !!!");
	    else
	    System.out.println(" :-( ...");
	}
	monArbitre.arrete();
    }


}
