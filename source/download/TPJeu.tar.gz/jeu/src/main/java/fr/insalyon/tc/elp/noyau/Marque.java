package fr.insalyon.tc.elp.noyau; 

/**
 * Classe modelisant une marque
 */
public class Marque {

    /** couleur de la marque */
    private final Couleur maCouleur; 

    /** 
     * Constructeur
     * @param couleur couleur de la marque
     */
    public Marque(Couleur uneCouleur) {
	maCouleur = uneCouleur; 
    }

    /**
     * Compare la couleur de la marque courante avec une autre couleur
     * @param uneCouleur 
     * @return vrai si les deux couleurs sont identiques, faux sinon
     */
    public boolean aMemeCouleur(Couleur uneCouleur) {
	if (uneCouleur == null) 
	    return false; 
	else 
	    return (maCouleur.equals(uneCouleur)); 
    }

    /**
     * Compare la couleur de la marque courante avec 
     * la couleur d'une autre marque
     * @param uneMarque 
     * @return vrai si les deux couleurs sont identiques, faux sinon
     */
    public boolean aMemeCouleur(Marque uneMarque) {
	if (uneMarque == null) 
	    return false; 
	else 
	    return (maCouleur.equals(uneMarque.maCouleur)); 
    }

    /**
     * @return chaine de caractere representant la marque
     */
    @Override 
    public String toString() {
	return maCouleur.toString(); 
    }
}
