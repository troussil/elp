package fr.insalyon.tc.elp.noyau; 

import java.util.ArrayList; 
import java.util.Collection; 

/**
 * Classe modelisant une position sur une grille 3x3. 
 * Elle est representee par un couple d'indices. 
 * 
 */
public final class Position {

    /** abscisse */
    private final int i;
    /** ordonnee */
    private final int j;
    /** borne superieure */
    private static final int borne = 3; 

    /**
     * Constructeur
     * @param aI abscisse de la position
     * @param aJ ordonnee de la position
     */
    public Position(int aI, int aJ) {
	i = shift(aI); 
	j = shift(aJ); 
    }

    /**
     * Recale un entier donne par modulo
     * de facon a ce qu'il tombe entre 0 (inclu) et borne (exclu)
     * @param x un entier
     * @return un entier entre 0 et borne
     */
    private int shift(int x) {
	if (x >= borne) 
	    return (x%borne); 
	else if (x < 0)
	    return ((-x)%borne);
	else
	    return x; 
    }

    /**
     * Methode comparant la position courante avec une autre. 
     * @param o une autre position
     * @return vrai si les deux positions ont meme coordonnees, 
     * faux sinon
     */
    @Override
    public boolean equals(Object o) {
	if (o == null)
	    return false; 
	else {
	    Position p = (Position) o; 
	    return ( (i == p.i) && (j == p.j) );
	} 
    }

    /**
     * Methode retournant le hash code de la position
     * @return hash code  
     */
    @Override
    public int hashCode() {
	return (i * borne) + j;  
    }

    /**
     * Methode renvoyant la representation textuelle de la position
     * @return les coordonnees separees par une virgule
     */
    @Override
    public String toString() {
	return ""+i+","+j; 
    }


    /**
     * Methode renvoyant la ligne (horizontale) de la position courante
     * comme un tableau de 3 positions
     * @return ligne
     */
    public Position[] ligne() {
	Position[] alignement = new Position[borne]; 
	for (int k = 0; k < borne; k++)
	    alignement[k] = new Position(i, k);
	return alignement; 
    }

    /**
     * Methode renvoyant la colonne (verticale) de la position courante
     * comme un tableau de 3 positions
     * @return colonne
     */
    public Position[] colonne() {
	Position[] alignement = new Position[borne]; 
	for (int k = 0; k < borne; k++)
	    alignement[k] = new Position(k, j);
	return alignement; 
    }

    /**
     * Methode renvoyant la diagonale (de pente 1) de la position courante
     * comme un tableau de 3 positions si i == j
     * @return diagonale si i == j, null sinon
     */
    public Position[] diag1() {
	Position[] alignement = null; 
	if (i == j) {
	    alignement = new Position[borne]; 
	    for (int k = 0; k < borne; k++)
		alignement[k] = new Position(k, k);
	}
	return alignement; 
    }

    /**
     * Methode renvoyant la diagonale (de pente -1) de la position courante
     * comme un tableau de 3 positions si i + j + 1 == borne
     * @return diagonale si i + j + 1 == borne, null sinon
     */
    public Position[] diag2() {
	Position[] alignement = null; 
	if ( (i + j + 1) == borne ) {
	    alignement = new Position[borne]; 
	    for (int k = 0; k < borne; k++)
		alignement[k] = new Position(k, (borne - 1 - k));
	}
	return alignement; 
    }


}
