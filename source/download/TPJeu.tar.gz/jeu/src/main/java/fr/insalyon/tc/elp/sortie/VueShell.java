package fr.insalyon.tc.elp.sortie; 

import fr.insalyon.tc.elp.noyau.Position; 
import fr.insalyon.tc.elp.noyau.Marque; 
import fr.insalyon.tc.elp.noyau.EnsembleDeMarques; 

/**
 * Classe modelisant la vue sur la sortie standard. 
 * Cette classe observe le modele et l'affiche a 
 * l'ecran apres chaque modification.
 */
public class VueShell {

    /**
     * Constructeur
     */
    public VueShell() {
	System.out.println("  0 1 2 "); 
	for (int i = 0; i < 3; i++) {
	    System.out.print(i + " "); 
	    for (int j = 0; j < 3; j++) {
		System.out.print("_ "); 
	    }
	    System.out.println(); 
	}
	System.out.println(); 
    }

    /**
     * Methode affichant sur la sortie standard la
     * representation textuelle de la grille
     */
    public void affichage(EnsembleDeMarques laGrille) {
	System.out.println("  0 1 2 "); 
	for (int i = 0; i < 3; i++) {
	    System.out.print(i + " "); 
	    for (int j = 0; j < 3; j++) {
		Marque m = laGrille.obtenirMarque(new Position(i,j)); 
		if (m == null)
		    System.out.print("_ "); 
		else
		    System.out.print(m + " "); 
	    }
	    System.out.println(); 
	}
	System.out.println(); 
    }
    

   
}
