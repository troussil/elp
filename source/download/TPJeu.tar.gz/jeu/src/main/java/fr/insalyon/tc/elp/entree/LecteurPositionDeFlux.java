package fr.insalyon.tc.elp.entree; 

import fr.insalyon.tc.elp.noyau.Position; 

import java.io.InputStream; 
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException; 

/**
 * Classe modelisant un lecteur de position
 * a partir d'un flux d'entree 
 */
public class LecteurPositionDeFlux implements LecteurPosition {

    /** flux d'entree */
    private BufferedReader monFlux; 

    /**
     * Constructeur 
     * @param unFlux flux d'entree
     */
    public LecteurPositionDeFlux(InputStream unFlux) {
	monFlux = new BufferedReader( new InputStreamReader(unFlux) );
    }

    /**
     * Retourne le position lue, 
     * puis remet a zero le position
     * @return position lue
     */
    @Override
    public Position lire() {
	Position res = null; 
	try {
	    String ligne = monFlux.readLine();  
	    String[] chaines = ligne.split(",");
	    if (chaines.length >= 2)
		res = new Position(Integer.parseInt(chaines[0]), Integer.parseInt(chaines[1])); 
	} catch (IOException e) {
	    System.err.println("IOException: tapez indiceLigne,indiceColonne");   
	}
	return res; 
    }


}
