package fr.insalyon.tc.elp.entree; 

import fr.insalyon.tc.elp.noyau.Position; 

/**
 * Interface listant les methodes 
 * que possedent les objets capable
 * de lire des positions
 */
public interface LecteurPosition {

    /**
     * Accede a la position lue 
     * @return la position
     */
    public Position lire(); 

}
